No.77 v1.0 — finite corroboration only.

Run with Python 3.10+ (standard library): `python -B -I verify.py`. Compare stdout with EXPECTED_RESULTS.txt, ignoring line endings. The frozen v0.1 verify.py and EXPECTED_RESULTS.txt are byte-identical to the mathematical source. The universal theorem has an analytic proof; this program does not prove it.
