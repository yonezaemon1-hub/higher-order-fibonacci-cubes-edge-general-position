from itertools import combinations, product
from collections import Counter
from fractions import Fraction

# Independent direct enumeration of words, versus recurrence.
def words(k,n):
    return [x for x in range(1<<n) if '1'*k not in format(x, f'0{n}b')]

def counts(k,N):
    a=[1]
    for n in range(1,N+1):
        a.append(2**n if n<k else sum(a[n-j] for j in range(1,k+1)))
    return a

cases=0
for k in range(3,13):
    a=counts(k,16)
    for n in range(2,15):
        v=words(k,n)
        assert len(v)==a[n]
        e=[sum((x>>i)&1 for x in v) for i in range(n)]
        assert e[0]==e[-1]==a[n]-a[n-1]
        assert all(e[i]==a[n]-a[i]*a[n-1-i] for i in range(n))
        assert max(e)==e[0]
        assert all(t<e[0] for t in e[1:-1]) if n>=k+1 else len(set(e))==1
        if n>=4:
            assert 11*2*e[0]>=10*a[n]
            if n==10 or n>10: assert 11*2*e[0]>10*a[n]
        cases+=1
print('PASS direct vertex and coordinate counts',cases)

# Check the conditional-probability lemma by exact counts for every
# conditioning on other members of an independent coordinate set, n<=10.
cases=0
for k in range(3,8):
    for n in range(2,11):
        v=words(k,n)
        for mask in range(1,1<<n):
            if mask & (mask<<1): continue
            for i in range(n):
                if not (mask>>i)&1: continue
                others=mask^(1<<i)
                c=Counter((x&others,(x>>i)&1) for x in v)
                for p in {p for p,b in c}:
                    zero,one=c[p,0],c[p,1]
                    assert one<=zero<=4*one
                    cases+=1
print('PASS exact conditional counts',cases)

# Explicitly test the six-coordinate two-mixed-triples event, all center
# patterns, in n=11..13, both k=3 and k=4.
cases=0
for k in (3,4):
    for n in range(11,14):
        v=words(k,n)
        for ix in combinations(range(n),6):
            if any(b==a+1 for a,b in zip(ix,ix[1:])): continue
            c=Counter(sum(((x>>j)&1)<<i for i,j in enumerate(ix)) for x in v)
            for p in range(64):
                bad=sum(w for q,w in c.items() if ((q^p)&7) not in (0,7) and ((q^p)>>3) not in (0,7))
                assert 625*bad>=81*len(v)
                cases+=1
print('PASS mixed-triple projection counts',cases)

# Separate exact maximum search for n=2..4. A triple is forbidden if
# some ordered orientation of its three edges lies on a Hamming geodesic.
from itertools import permutations
cases=0
for k in (3,4,5):
    for n in range(2,5):
        v=words(k,n)
        edges=[(x,x^(1<<i)) for x in v for i in range(n) if (x>>i)&1]
        N=len(edges)
        bad=[[] for _ in edges]
        dist=lambda a,b:(a^b).bit_count()
        for triple in combinations(range(N),3):
            if any(3+dist(a[1],b[0])+dist(b[1],c[0])==dist(a[0],c[1])
                   for p in permutations(triple) for a,b,c in product(*[(edges[j],edges[j][::-1]) for j in p])):
                i,j,l=triple; bad[l].append((1<<i)|(1<<j))
        target=2*(len(v)-len(words(k,n-1)))
        # Test for one more edge, with cardinality pruning and all triples.
        def exists(i,mask,count):
            if count>target:return True
            if count+N-i<=target:return False
            if not any(mask & b == b for b in bad[i]):
                if exists(i+1,mask|(1<<i),count+1):return True
            return exists(i+1,mask,count)
        assert not exists(0,0,0)
        cases+=1
print('PASS separate forbidden-triple upper searches',cases)
print('PASS FINITE CORROBORATION ONLY; ANALYTIC PROOF REQUIRES AUDIT')
